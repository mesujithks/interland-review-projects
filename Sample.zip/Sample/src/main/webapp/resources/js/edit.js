$(document).ready(function(){
	let searchParams = new URLSearchParams(window.location.search);
	let param = searchParams.get('id');
	$.ajax({
		url:"getUpdate",
		type:'GET',
		dataType:'JSON',
		data:{"id":param},
		success:function(data){
			$("#name").val(data.name);
			$("#email").val(data.email);
			$("#phone").val(data.phone);
			$("#city").val(data.city);
		},
		error:function(data){
			alert("error");
		}
	});
	$("form").submit(function(e){
		e.preventDefault();
		$.ajax({
			url:"userEdit",
			type:'POST',
			data:{
				"id":param,
				"name":$("#name").val(),
				"email":$("#email").val(),
				"phone":$("#phone").val(),
				"city":$("#city").val()},
			success:function(data){
				alert("Data updated successfully");
				
			},
			error:function(data){
				alert("Error while saving data");
			}
		});
	});
});