package com.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.sample.dao.Dao;
import com.sample.model.User;

@Service
public class DisplayServiceImpl implements DisplayService{
	@Autowired
	Dao dao;
	public JsonArray display(){
		List<User> beanList=dao.display();
		Gson gson=new Gson();
		String element=gson.toJson(beanList);
		JsonArray json=new JsonParser().parse(element).getAsJsonArray();
		return json;
	}
	public void add(User user) {
		dao.add(user);
	}
	public User getUpdate(User user) {
		return dao.getUpdate(user);
	}
	public void setUpdate(User user) {
		dao.setUpdate(user);
	}
	public void delete(User user) {
		dao.delete(user);
	}
}
