package com.sample.service;


import com.google.gson.JsonArray;
import com.sample.model.User;

public interface DisplayService {
	public JsonArray display();
	public void add(User user);
	public User getUpdate(User user);
	public void setUpdate(User user);
	public void delete(User user);
}
