package com.sample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.sample.model.User;
import com.sample.service.DisplayService;

@Controller
public class ControllerClass {
	@Autowired
	DisplayService dis;
	
	@RequestMapping("/displayUser")
	@ResponseBody
	public JsonArray display() {
		
		JsonArray json=dis.display();
		return json;
	}
	@RequestMapping(value="/userAdd", method=RequestMethod.POST)
	public String add(User user) {
		dis.add(user);
		return "UserAdd";
	}
	@RequestMapping(value="/getUpdate", method=RequestMethod.GET)
	@ResponseBody
	public User getUpdate(User user) {
		return dis.getUpdate(user);
	}
	@RequestMapping(value="/userEdit", method=RequestMethod.POST)
	public String setUpdate(User user) {
		dis.setUpdate(user);
		return "UserEdit";
	}
	@RequestMapping(value="/delete", method=RequestMethod.GET)
	public String delete(User user) {
		dis.delete(user);
		return "display";
	}
}
