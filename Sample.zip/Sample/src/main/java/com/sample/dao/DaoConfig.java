package com.sample.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.sample.model.User;

public class DaoConfig {
	public static Session daoConfig() {
		Configuration config=new Configuration().configure().addAnnotatedClass(User.class);
		SessionFactory sf=config.buildSessionFactory();
		Session session=sf.openSession();
		return session;
	}
}
