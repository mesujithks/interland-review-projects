package com.sample.dao;

import java.util.List;

import com.sample.model.User;

public interface Dao {
	public List<User> display();
	public void add(User user);
	public User getUpdate(User user);
	public void setUpdate(User user);
	public void delete(User user);
}
