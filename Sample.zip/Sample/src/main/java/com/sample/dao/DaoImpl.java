package com.sample.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.sample.model.User;
@Repository
public class DaoImpl implements Dao{
	@Transactional
	public List<User> display(){
		List<User> beanList=null;
		Session session=DaoConfig.daoConfig();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			beanList=(List<User>)session.createCriteria(User.class).list();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return beanList;
	}
	
	@Transactional
	public void add(User user) {
		Session session=DaoConfig.daoConfig();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.save(user);
			tx.commit();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@Transactional
	public User getUpdate(User user) {
		User currUser=new User();
		Session session=DaoConfig.daoConfig();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			currUser=(User)session.get(User.class,user.getId());
			tx.commit();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return currUser;
	}
	
	@Transactional
	public void setUpdate(User user) {
		Session session=DaoConfig.daoConfig();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.update(user);
			tx.commit();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@Transactional
	public void delete(User user) {
		Session session=DaoConfig.daoConfig();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.delete(user);
			tx.commit();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
