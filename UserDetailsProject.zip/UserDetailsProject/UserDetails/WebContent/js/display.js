$(document).ready(function() {
	var content="";
	var id;
	$.ajax({
		url:"display",
		type:'GET',
		dataType:"JSON",
		success:function(data){
			for (var x = 0; x < data.length; x++) {
                content = "<tr>";
                content += "<td>"+(x+1)+"</td>";
                content += "<td>"+data[x].name+"</td>";
                content += "<td>"+data[x].email+"</td>";
                content += "<td>"+data[x].phone+"</td>";
                content += "<td>"+data[x].city+"</td>";
                content += "<td><button class='edit' id='"+data[x].id+"'>Edit</button</td>";
                content += "<td><button class='delete' id='"+data[x].id+"'>Delete</button</td>";
                content += "<tr>";
                $("tbody").append(content);
            }
		}
	});
	$("#buttonid_add").click(function() {
		window.location.href = "UserAdd.jsp";
	});
	$(document).on('click','.edit',function(){
		window.location.href = "UserEdit.jsp?id="+this.id+"";
	});
	$(document).on('click','.delete',function(){
		if (confirm("Delete Id "+this.id+" data")) {
			$.ajax({
				url:"delete",
				type:'GET',
				dataType:'JSON',
				data:{"id":this.id},
				success:function(data){
					alert("Data removed successfully");
					location.reload();
				},
				error:function(data){
					location.reload();
				}
			});
		}
	});

});