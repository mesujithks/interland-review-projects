package com.user.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import com.user.model.Bean;
import com.user.util.ConnectionManager;

public class Dao { 
	@SuppressWarnings("deprecation")
	public static List<Bean> display(){
		List<Bean> beanList=null;
		Configuration config=new Configuration().configure().addAnnotatedClass(Bean.class);
		SessionFactory sf=config.buildSessionFactory();
		Session session=sf.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			beanList=(List<Bean>)session.createCriteria(Bean.class).list();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return beanList;
	}
	public static Bean getEditData(Bean user) throws SQLException {
		Bean currUser=new Bean();
		Configuration config=new Configuration().configure().addAnnotatedClass(Bean.class);
		SessionFactory sf=config.buildSessionFactory();
		Session session=sf.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			currUser=(Bean)session.get(Bean.class,user.getId());
			tx.commit();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return currUser;
	}
	public static void updateData(Bean user) throws SQLException {
		Configuration config=new Configuration().configure().addAnnotatedClass(Bean.class);
		SessionFactory sf=config.buildSessionFactory();
		Session session=sf.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.update(user);
			tx.commit();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public static void addData(Bean user) throws SQLException {
		Configuration config=new Configuration().configure().addAnnotatedClass(Bean.class);
		SessionFactory sf=config.buildSessionFactory();
		Session session=sf.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.save(user);
			tx.commit();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public static void deleteData(Bean user) throws SQLException {
		Configuration config=new Configuration().configure().addAnnotatedClass(Bean.class);
		SessionFactory sf=config.buildSessionFactory();
		Session session=sf.openSession();
		Transaction tx=null;
		try {
			tx=session.beginTransaction();
			session.delete(user);
			tx.commit();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
 