package com.user.controller;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.user.model.Bean;
import com.user.service.DisplayService;

@WebServlet("/display")
public class DisplayController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Bean> beanList=DisplayService.display();
		Gson gson=new Gson();
		String element=gson.toJson(beanList);
		JsonArray json=new JsonParser().parse(element).getAsJsonArray();
		response.getWriter().print(json);
	}

}
