
  package com.user.controller;
  
  import java.io.IOException; import java.sql.SQLException;
  
  import javax.servlet.ServletException; import
  javax.servlet.annotation.WebServlet; import javax.servlet.http.HttpServlet;
  import javax.servlet.http.HttpServletRequest; import
  javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.user.model.Bean; import com.user.service.DisplayService;
import com.user.service.EditFillService;
  
  
  @WebServlet("/editFill") public class EditFillController extends HttpServlet
  { private static final long serialVersionUID = 1L;
  
  protected void doGet(HttpServletRequest req, HttpServletResponse response)
  throws ServletException, IOException { Bean user=new Bean();
  user.setId(Integer.parseInt(req.getParameter("id")));
  try { 
	  Bean currUser=EditFillService.editFill(user);
	  Gson gson=new Gson();
	  String json=gson.toJson(currUser);
	  response.getWriter().print(json);
  }
  catch (SQLException e) { // TODO Auto-generated catch block
  e.printStackTrace(); } }
  
  }
 