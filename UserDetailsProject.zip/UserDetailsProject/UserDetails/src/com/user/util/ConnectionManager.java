package com.user.util;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public class ConnectionManager {
	static Connection conn=null;
	public static Connection getConnection() {
		String url="jdbc:mysql://localhost:3306/users";
		String driver="com.mysql.jdbc.Driver";
		try {
			Class.forName(driver);
			try {
				conn=(Connection)DriverManager.getConnection(url,"root","admin");
				return conn;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
}
