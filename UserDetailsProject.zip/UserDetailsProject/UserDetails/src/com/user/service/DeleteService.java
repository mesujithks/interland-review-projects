package com.user.service;

import java.sql.SQLException;

import com.user.dao.Dao;
import com.user.model.Bean;

public class DeleteService {
	public static void deleteData(Bean user) throws SQLException {
		Dao.deleteData(user);
	}
}
