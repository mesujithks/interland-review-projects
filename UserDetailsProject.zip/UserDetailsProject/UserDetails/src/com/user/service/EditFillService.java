package com.user.service;

import java.sql.SQLException;

import com.user.dao.Dao;
import com.user.model.Bean;

public class EditFillService {
	public static Bean editFill(Bean user) throws SQLException {
		return Dao.getEditData(user);
	}
}
