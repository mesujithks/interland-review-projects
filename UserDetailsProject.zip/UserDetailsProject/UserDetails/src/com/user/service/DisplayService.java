package com.user.service;

import java.util.List;

import com.user.dao.Dao;
import com.user.model.Bean;

public class DisplayService {
	public static List<Bean> display(){
		return Dao.display();
	}
}
