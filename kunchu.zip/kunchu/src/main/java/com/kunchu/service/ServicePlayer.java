package com.kunchu.service;

import java.util.List;

import com.kunchu.model.Player;

public interface ServicePlayer {
 public List<Player> serviceDisplay();
 public String serviceAdd(Player player);
}
