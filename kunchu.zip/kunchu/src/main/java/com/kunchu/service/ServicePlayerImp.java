package com.kunchu.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kunchu.Dao.Dao;
import com.kunchu.model.Player;

@Service
public class ServicePlayerImp implements ServicePlayer{
	@Autowired 
	Dao d;

	public List<Player> serviceDisplay() {
		return d.daoDisplay();
		
	}
	public String serviceAdd(Player player)
	{
		return d.daoAdd(player);
	}

}
