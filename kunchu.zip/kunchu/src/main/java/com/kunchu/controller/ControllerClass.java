package com.kunchu.controller;

import java.util.List;

import org.codehaus.jackson.map.util.JSONPObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.kunchu.model.Player;
import com.kunchu.service.ServicePlayer;


@Controller
public class ControllerClass {
	@Autowired
	ServicePlayer s;
	
	@RequestMapping("/display")
	@ResponseBody
	public List<Player> display()
	{
		List<Player> p=s.serviceDisplay();
		return p;
	}
	@RequestMapping("/add")
	public String add()
	{
		return "add";
	}
	@RequestMapping("/addtodb")
	@ResponseBody
	public String addToDb(Player player)
	{
	  return s.serviceAdd(player);
	}
	@RequestMapping("/edit")
	public String edit()
	{
		int a=
		return "edit";
		
	}
	

}
