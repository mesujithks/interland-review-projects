package com.kunchu.Dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.kunchu.model.Player;

@Repository
public class DaoImpl implements Dao{
	@Autowired
	SessionFactory session;

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Player> daoDisplay() {
		List<Player> beanList=null;
		try {
			beanList=session.getCurrentSession().createCriteria(Player.class).list();
		} catch (Exception e) {
			System.out.println(e);
		}
		return beanList;
		
	}
	
	@Transactional
	public String daoAdd(Player player) {
		String result;
		try {
			System.out.println("inside dao");
			session.getCurrentSession().saveOrUpdate(player);
			result = "Added successfully";
		} catch (Exception e) {
			System.out.println(e);
			result = "Error";
		}
		return result;
	}

	
}
