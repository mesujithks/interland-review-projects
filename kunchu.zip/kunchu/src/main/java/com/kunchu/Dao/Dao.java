package com.kunchu.Dao;

import java.util.List;

import com.kunchu.model.Player;

public interface Dao {

	public List<Player> daoDisplay();
	public String daoAdd(Player player);
}
