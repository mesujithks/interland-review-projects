package com.interland.OnlineCourse.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.interland.OnlineCourse.dto.UserEdit;
import com.interland.OnlineCourse.model.Course;
import com.interland.OnlineCourse.model.Notice;
import com.interland.OnlineCourse.service.AdminService;

@Controller("admin")
@RequestMapping("admin")
public class AdminController {
	@Autowired
	AdminService service;
	
	@RequestMapping("index")
	public String indexPage() {
		return "admin/index";
	}
	

	@RequestMapping(value = "StudentTableList", method = RequestMethod.POST)
	public @ResponseBody org.json.simple.JSONObject studentDetails(HttpServletRequest request) {
		org.json.simple.JSONObject res = null;
		int idisplaylength = Integer.parseInt(request.getParameter("iDisplayLength"));
		int displaystart = Integer.parseInt(request.getParameter("iDisplayStart"));
		String sSearch = request.getParameter("sSearch");
		String searchParam = request.getParameter("searchData");

		try {
			res = service.getStudentDetails(searchParam, sSearch, displaystart, idisplaylength);
			// System.out.println(res);
		} catch (Exception e) {

		}
		// System.out.println(res.toString());
		return res;
	}

	@RequestMapping(value = "DeleteStudentBy")
	@ResponseBody
	public String deleteStudent(HttpServletRequest request) {
		String res = "0";
		int id;
		try {
			id = Integer.parseInt(request.getParameter("id"));
			res = service.deleteStudentService(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@RequestMapping("EditStudentBy")
	public ModelAndView editStudent(@RequestParam int id) {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("admin/EditStudent");
		try {
			mv.addObject("student", service.getStudent(id));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mv;

	}

	@RequestMapping(value = "EditForm", method = RequestMethod.POST)
	@ResponseBody
	public String editStudentForm(UserEdit user) {

		String res = null;
		try {
			res = service.editStudentFormService(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@RequestMapping("ViewFaculty")
	public String facultyPage() {
		return "admin/faculty";
	}

	@RequestMapping(value = "FacultyTableList", method = RequestMethod.POST)
	public @ResponseBody org.json.simple.JSONObject facultyDetails(HttpServletRequest request) {
		org.json.simple.JSONObject res = null;
		int idisplaylength = Integer.parseInt(request.getParameter("iDisplayLength"));
		int displaystart = Integer.parseInt(request.getParameter("iDisplayStart"));
		String sSearch = request.getParameter("sSearch");
		String searchParam = request.getParameter("searchData");

		try {
			res = service.getFacultyDetails(searchParam, sSearch, displaystart, idisplaylength);
			// System.out.println(res);
		} catch (Exception e) {

		}
		// System.out.println(res.toString());
		return res;
	}

	@RequestMapping("ViewCourse")
	public String coursePage() {
		return "admin/course";
	}

	@RequestMapping(value = "CourseTableList", method = RequestMethod.POST)
	public @ResponseBody org.json.simple.JSONObject courseDetails(HttpServletRequest request) {
		org.json.simple.JSONObject res = null;
		int idisplaylength = Integer.parseInt(request.getParameter("iDisplayLength"));
		int displaystart = Integer.parseInt(request.getParameter("iDisplayStart"));
		String sSearch = request.getParameter("sSearch");
		String searchParam = request.getParameter("searchData");

		try {
			res = service.getCourseDetails(searchParam, sSearch, displaystart, idisplaylength);
			// System.out.println(res);
		} catch (Exception e) {

		}
		// System.out.println(res.toString());
		return res;
	}

	@RequestMapping("AddCourse")
	public String courseAdd() {
		return "admin/AddCourse";
	}

	@RequestMapping(value = "AddCourseForm", method = RequestMethod.POST)
	@ResponseBody
	public String addCourseAction(@ModelAttribute Course course) {
		System.out.println(course);

		String res = null;
		try {
			res = service.addCourseService(course);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@RequestMapping(value = "EditCourseForm", method = RequestMethod.POST)
	@ResponseBody
	public String editCourseForm(@ModelAttribute Course course) {

		String res = null;
		try {
			res = service.editCourseService(course);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@RequestMapping(value = "DeleteCourseBy")
	@ResponseBody
	public String deleteCourse(HttpServletRequest request) {
		String res = "0";
		int id;
		try {
			id = Integer.parseInt(request.getParameter("id"));
			res = service.deleteCourseService(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@RequestMapping("EditCourseBy")
	public ModelAndView editCourse(@RequestParam int id) {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("admin/EditCourse");
		try {
			mv.addObject("course", service.getCourse(id));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mv;

	}

	@RequestMapping("Notice")
	public String noticePage() {
		return "admin/notice";
	}

	@RequestMapping(value = "NoticeTableList", method = RequestMethod.POST)
	public @ResponseBody org.json.simple.JSONObject noticeDetails(HttpServletRequest request) {
		org.json.simple.JSONObject res = null;
		int idisplaylength = Integer.parseInt(request.getParameter("iDisplayLength"));
		int displaystart = Integer.parseInt(request.getParameter("iDisplayStart"));
		String sSearch = request.getParameter("sSearch");
		String searchParam = request.getParameter("searchData");

		try {
			res = service.getNoticeDetails(searchParam, sSearch, displaystart, idisplaylength);
			// System.out.println(res);
		} catch (Exception e) {

		}
		// System.out.println(res.toString());
		return res;
	}
	@RequestMapping("AddNotice")
	public String noticeAddPage() {
		return "admin/addnotice";
	}
	
	@RequestMapping(value = "AddNoticeForm", method = RequestMethod.POST)
	@ResponseBody
	public String addNoticeAction(@ModelAttribute Notice notice) {
		System.out.println(notice);

		String res = null;
		try {
			res = service.addNoticeService(notice);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@RequestMapping("EditNoticeBy")
	public ModelAndView editNotice(@RequestParam int id) {

		ModelAndView mv = new ModelAndView();
		mv.setViewName("admin/EditNotice");
		try {
			mv.addObject("notice", service.getNotice(id));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mv;

	}
	
	@RequestMapping(value = "EditNoticeForm", method = RequestMethod.POST)
	@ResponseBody
	public String editNoticeForm(@ModelAttribute Notice notice) {

		String res = null;
		try {
			res = service.editNoticeService(notice);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

	@RequestMapping(value = "DeleteNoticeBy")
	@ResponseBody
	public String deleteNotice(HttpServletRequest request) {
		String res = "0";
		int id;
		try {
			id = Integer.parseInt(request.getParameter("id"));
			res = service.deleteNoticeService(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}

}
