package com.interland.OnlineCourse.service;

import java.text.SimpleDateFormat;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.interland.OnlineCourse.dao.UserDAO;
import com.interland.OnlineCourse.dto.UserLogin;
import com.interland.OnlineCourse.dto.UserRegister;
import com.interland.OnlineCourse.model.User;
import com.interland.OnlineCourse.service.MianService;

@Service
public class MianServiceImpl implements MianService {

	@Autowired
	UserDAO dao;

	public HashMap<String, String> registerService(UserRegister userRegister) {
		User user = new User();
		HashMap<String, String> response = new HashMap<String, String>();
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(); // Strength set as 12

		try {
			user.setName(userRegister.getName());
			user.setEmail(userRegister.getEmail());
			user.setPass(userRegister.getPassword());
			user.setType(userRegister.getType());
			user.setMobile(userRegister.getMobile());
			user.setGender(userRegister.getGender());
			user.setImage("/resources/upload/images/avatar.png");
			user.setDob(new SimpleDateFormat("yyyy-MM-dd").parse(userRegister.getDob()));

			System.out.println(encoder.encode(userRegister.getPassword()));
			if (dao.addOrUpdate(user)) {
				response.put("flag", "true");
				response.put("message", "Success");
			} else {
				response.put("flag", "false");
				response.put("message", "Error");
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return response;
	}

	public User loginService(UserLogin userLogin) {
		User user = null;
		
		try {
			user = dao.getLogin(userLogin);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;

	}

}
