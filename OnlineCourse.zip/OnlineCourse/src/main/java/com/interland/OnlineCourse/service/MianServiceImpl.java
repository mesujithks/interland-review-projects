package com.interland.OnlineCourse.service;

import java.text.SimpleDateFormat;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.interland.OnlineCourse.dao.UserDAO;
import com.interland.OnlineCourse.dto.UserLogin;
import com.interland.OnlineCourse.dto.UserRegister;
import com.interland.OnlineCourse.model.User;
import com.interland.OnlineCourse.service.MianService;

@Service
public class MianServiceImpl implements MianService{
	
	@Autowired
	UserDAO dao;

	public HashMap<String, String> registerService(UserRegister userRegister) {
		User user =new User();
		HashMap<String, String> response = new HashMap<String, String>();
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(); // Strength set as 12
		
		try {
			user.setName(userRegister.getName());
			user.setEmail(userRegister.getEmail());
			user.setPass(userRegister.getPassword());
			user.setType(userRegister.getType());
			user.setMobile(userRegister.getMobile());
			user.setGender(userRegister.getGender());
			user.setImage("/resources/upload/images/avatar.png");
			user.setDob(new SimpleDateFormat("yyyy-MM-dd").parse(userRegister.getDob()));
			
			System.out.println(encoder.encode(userRegister.getPassword()));
			if(dao.addOrUpdate(user)) {
				response.put("flag", "true");
				response.put("message", "Success");
			}else {
				response.put("flag", "false");
				response.put("message", "Error");
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return response;
	}

	public ModelAndView loginService(UserLogin userLogin, RedirectAttributes redirectAttributes) {
		 	User user=null;
			ModelAndView mv = new ModelAndView();
			mv.setViewName("index");
			try {
				user = dao.getLogin(userLogin);
				if(user != null) {
					if(user.getType().equals("admin")) 
						mv.setViewName("redirect:admin/index");
					else if(user.getType().equals("faculty")) 
						mv.setViewName("faculty/index");
					else if(user.getType().equals("student"))
						mv.setViewName("student/index");
					
					mv.addObject("user", user);
					}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			redirectAttributes.addFlashAttribute("user", user);
			return mv;
	
	}

}
