package com.interland.OnlineCourse.service;

import org.json.simple.JSONObject;

import com.interland.OnlineCourse.dto.UserEdit;
import com.interland.OnlineCourse.model.User;

public interface AdminService {

	JSONObject getStudentDetails(String searchParam, String sSearch, int displaystart, int idisplaylength);

	String deleteStudentService(int id);

	User getStudent(int id);

	String editStudentFormService(UserEdit userEdit);

	JSONObject getFacultyDetails(String searchParam, String sSearch, int displaystart, int idisplaylength);

	JSONObject getCourseDetails(String searchParam, String sSearch, int displaystart, int idisplaylength);

}
