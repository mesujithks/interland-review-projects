package com.interland.OnlineCourse.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="courses")
public class Course {
@Id
	private int courseId;
	private String courseName;
	private String shortD;
	private String longD;
	private String courseImage;
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getShortD() {
		return shortD;
	}
	public void setShortD(String shortD) {
		this.shortD = shortD;
	}
	public String getLongD() {
		return longD;
	}
	public void setLongD(String longD) {
		this.longD = longD;
	}
	public String getCourseImage() {
		return courseImage;
	}
	public void setCourseImage(String courseImage) {
		this.courseImage = courseImage;
	}
	
	
}
