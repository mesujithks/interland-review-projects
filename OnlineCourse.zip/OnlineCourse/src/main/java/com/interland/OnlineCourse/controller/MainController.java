package com.interland.OnlineCourse.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.interland.OnlineCourse.dto.UserLogin;
import com.interland.OnlineCourse.dto.UserRegister;
import com.interland.OnlineCourse.service.MianService;


@Controller
public class MainController {
	
	@Autowired
	MianService service;
	
	@RequestMapping("/index")
	public String indexPage() {
		return "index";
	}
	
	@RequestMapping(value="/RegisterForm", method=RequestMethod.POST)
	public ModelAndView indexAction(@ModelAttribute UserRegister userRegister) {
		System.out.println(userRegister);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");
		mv.addObject("result", service.registerService(userRegister));
		return mv;
	}
	
	@RequestMapping(value="/LoginForm", method=RequestMethod.POST)
	public ModelAndView indexAction(@ModelAttribute UserLogin userLogin, RedirectAttributes redirectAttributes) {
		System.out.println(userLogin);
		
		return service.loginService(userLogin, redirectAttributes);
	}
	

}
