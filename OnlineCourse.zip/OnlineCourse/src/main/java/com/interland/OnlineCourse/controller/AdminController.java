package com.interland.OnlineCourse.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.interland.OnlineCourse.dto.UserEdit;
import com.interland.OnlineCourse.model.User;
import com.interland.OnlineCourse.service.AdminService;

@Controller("admin")
public class AdminController {
	@Autowired
	AdminService service;
	@RequestMapping("admin/index")
	public String indexPage() {
		return "admin/index";
	}
	@RequestMapping(value = "admin/StudentTableList", method = RequestMethod.POST)
	public @ResponseBody org.json.simple.JSONObject employeeDetails( HttpServletRequest request)  {	
		org.json.simple.JSONObject res = null;
		int idisplaylength = Integer.parseInt(request.getParameter("iDisplayLength"));
        int displaystart = Integer.parseInt(request.getParameter("iDisplayStart"));
        String sSearch = request.getParameter("sSearch");
        String searchParam = request.getParameter("searchData");
        
		try {
			res = service.getStudentDetails(searchParam, sSearch, displaystart, idisplaylength);
			//System.out.println(res);
		} catch (Exception e) {
		
		}
		//System.out.println(res.toString());
		return res;
	}
	@RequestMapping(value = "admin/DeleteStudentBy")
	@ResponseBody
	public String deleteConsumer(HttpServletRequest request) {
		String res = "0";
		int id;
		try {
			id = Integer.parseInt(request.getParameter("id"));
			res = service.deleteStudentService(id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
	@RequestMapping("admin/EditStudentBy")
	public ModelAndView editStudent(@RequestParam int id) {
	
		ModelAndView mv=new ModelAndView();
		mv.setViewName("admin/EditStudent");
		try {
			mv.addObject("student", service.getStudent(id));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mv;
		
	}
	@RequestMapping(value ="admin/EditForm", method = RequestMethod.POST)
	@ResponseBody
	public String editStudentForm(UserEdit user) {
		 
		String res = null;
		try {
			res = service.editStudentFormService(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return res;
	}
	@RequestMapping("admin/ViewFaculty")
	public String facultyPage() {
		return "admin/faculty";
	}
	@RequestMapping(value = "admin/FacultyTableList", method = RequestMethod.POST)
	public @ResponseBody org.json.simple.JSONObject facultyDetails( HttpServletRequest request)  {	
		org.json.simple.JSONObject res = null;
		int idisplaylength = Integer.parseInt(request.getParameter("iDisplayLength"));
        int displaystart = Integer.parseInt(request.getParameter("iDisplayStart"));
        String sSearch = request.getParameter("sSearch");
        String searchParam = request.getParameter("searchData");
        
		try {
			res = service.getFacultyDetails(searchParam, sSearch, displaystart, idisplaylength);
			//System.out.println(res);
		} catch (Exception e) {
		
		}
		//System.out.println(res.toString());
		return res;
	}
	@RequestMapping("admin/course")
	public String coursePage() {
		return "admin/course";
	}
	@RequestMapping(value = "admin/CourseTableList", method = RequestMethod.POST)
	public @ResponseBody org.json.simple.JSONObject courseDetails( HttpServletRequest request)  {	
		org.json.simple.JSONObject res = null;
		int idisplaylength = Integer.parseInt(request.getParameter("iDisplayLength"));
        int displaystart = Integer.parseInt(request.getParameter("iDisplayStart"));
        String sSearch = request.getParameter("sSearch");
        String searchParam = request.getParameter("searchData");
        
		try {
			res = service.getCourseDetails(searchParam, sSearch, displaystart, idisplaylength);
			//System.out.println(res);
		} catch (Exception e) {
		
		}
		//System.out.println(res.toString());
		return res;
	}


}
