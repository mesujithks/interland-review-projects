package com.interland.OnlineCourse.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.interland.OnlineCourse.service.FacultyService;

@Controller("faculty")
public class FacultyController {

	@Autowired
	FacultyService service;

	@RequestMapping("faculty/index")
	public String indexPage() {
		return "faculty/index";
	}
	@RequestMapping(value = "faculty/CourseTableList", method = RequestMethod.POST)
	public @ResponseBody org.json.simple.JSONObject courseDetails(HttpServletRequest request) {
		org.json.simple.JSONObject res = null;
		int idisplaylength = Integer.parseInt(request.getParameter("iDisplayLength"));
		int displaystart = Integer.parseInt(request.getParameter("iDisplayStart"));
		String sSearch = request.getParameter("sSearch");
		String searchParam = request.getParameter("searchData");

		try {
			res = service.getCourseDetails(searchParam, sSearch, displaystart, idisplaylength);
			// System.out.println(res);
		} catch (Exception e) {

		}
		// System.out.println(res.toString());
		return res;
	}
	@RequestMapping("faculty/Notice")
	public String NoticePage() {
		return "faculty/notice";
	}
	@RequestMapping(value = "faculty/NoticeTableList", method = RequestMethod.POST)
	public @ResponseBody org.json.simple.JSONObject noticeDetails(HttpServletRequest request) {
		org.json.simple.JSONObject res = null;
		int idisplaylength = Integer.parseInt(request.getParameter("iDisplayLength"));
		int displaystart = Integer.parseInt(request.getParameter("iDisplayStart"));
		String sSearch = request.getParameter("sSearch");
		String searchParam = request.getParameter("searchData");

		try {
			res = service.getNoticeDetails(searchParam, sSearch, displaystart, idisplaylength);
			// System.out.println(res);
		} catch (Exception e) {

		}
		// System.out.println(res.toString());
		return res;
	}

}
