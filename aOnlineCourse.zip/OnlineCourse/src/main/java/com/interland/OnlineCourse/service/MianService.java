package com.interland.OnlineCourse.service;

import java.util.HashMap;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.interland.OnlineCourse.dto.UserLogin;
import com.interland.OnlineCourse.dto.UserRegister;
import com.interland.OnlineCourse.model.User;

public interface MianService {
	
	public HashMap<String, String> registerService(UserRegister userRegister);

	public User loginService(UserLogin userLogin);

}
