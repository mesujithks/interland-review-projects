package com.mesujithks.ServletLogin.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mesujithks.ServletLogin.model.UserBean;
import com.mesujithks.ServletLogin.service.RegisterService;

@WebServlet("/RegisterController")
public class RegisterController extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		UserBean user = new UserBean();
	    user.setUsername(request.getParameter("username"));
	    user.setFirstName(request.getParameter("firstname"));
	    user.setLastName(request.getParameter("lastname"));
	    user.setPassword(request.getParameter("password"));
	    
	    RegisterService registerService = new RegisterService(request, response);
	    registerService.registerAction(user);
	}

}
