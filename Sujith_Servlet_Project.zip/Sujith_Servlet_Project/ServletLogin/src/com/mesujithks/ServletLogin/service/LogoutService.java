package com.mesujithks.ServletLogin.service;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LogoutService {
	
	HttpServletRequest request;
	HttpServletResponse response;
	
	public LogoutService(HttpServletRequest request, HttpServletResponse response) {
		this.request = request;
		this.response = response;
	}


	public void logout() {
		try {
			HttpSession session = request.getSession(false);
			if(session != null){
				session.invalidate();
			}
			response.sendRedirect("index.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
