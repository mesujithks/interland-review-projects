package com.mesujithks.ServletLogin.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mesujithks.ServletLogin.dao.UserDAO;
import com.mesujithks.ServletLogin.model.UserBean;

public class RegisterService {

	HttpServletRequest request; 
	HttpServletResponse response;
	
	public RegisterService(HttpServletRequest request, HttpServletResponse response) {
		this.request = request;
		this.response = response;
	}
	
	public void registerAction(UserBean user) {
		try{	    
		     user = UserDAO.signup(user);
			   		    
		     if (user.isValid()){
		          response.sendRedirect("index.jsp"); //logged-in page      		
		     }else 
		          response.sendRedirect("signup.jsp"); //error page 
		} catch (Throwable theException) 	    {
		     System.out.println(theException); 
		}
	}
}
