package com.mesujithks.ServletLogin.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mesujithks.ServletLogin.dao.UserDAO;
import com.mesujithks.ServletLogin.model.UserBean;

public class EditService {
	HttpServletRequest request; 
	HttpServletResponse response;
	
	public EditService(HttpServletRequest request, HttpServletResponse response) {
		this.request = request;
		this.response = response;
	}
	
	public void editAction(UserBean user) {
		try{	    
		     user = UserDAO.edit(user);
			   		    
		     if (user.isValid()){
		          response.sendRedirect("userLogged.jsp"); //logged-in page      		
		     }else 
		          response.sendRedirect("editProfile.jsp"); //error page 
		} catch (Throwable theException) 	    {
		     System.out.println(theException); 
		}
	}

}
