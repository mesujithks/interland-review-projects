package com.mesujithks.ServletLogin.dao;

import java.sql.*;

import com.mesujithks.ServletLogin.model.UserBean;
import com.mesujithks.ServletLogin.util.ConnectionManager;

public class UserDAO {
   static Connection currentCon = null;
   static ResultSet rs = null;  

   public static UserBean login(UserBean bean) {
	
      //preparing some objects for connection 
      Statement stmt = null;    
	
      String username = bean.getUsername();    
      String password = bean.getPassword();   
	    
      String searchQuery =
            "select * from user where username='"
                     + username
                     + "' AND password='"
                     + password
                     + "'";
	    
   // "System.out.println" prints in the console; Normally used to trace the process
   System.out.println("Your user name is " + username);          
   System.out.println("Your password is " + password);
   System.out.println("Query: "+searchQuery);
	    
   try {
      //connect to DB 
      currentCon = ConnectionManager.getConnection();
      stmt=currentCon.createStatement();
      rs = stmt.executeQuery(searchQuery);	        
      boolean more = rs.next();
	       
      // if user does not exist set the isValid variable to false
      if (!more) {
         System.out.println("Sorry, you are not a registered user! Please sign up first");
         bean.setValid(false);
      } 
	        
      //if user exists set the isValid variable to true
      else if (more) {
    	 int id =rs.getInt("uid");
         String firstName = rs.getString("first_name");
         String lastName = rs.getString("last_name");
	     	
         System.out.println("Welcome " + firstName);
         bean.setId(id);
         bean.setFirstName(firstName);
         bean.setLastName(lastName);
         bean.setValid(true);
      }
   } catch (Exception ex) {
      System.out.println("Log In failed: An Exception has occurred! " + ex);
   } 
	    
   //some exception handling
   finally {
      if (rs != null)	{
         try {
            rs.close();
         } catch (Exception e) {}
            rs = null;
         }
	
      if (stmt != null) {
         try {
            stmt.close();
         } catch (Exception e) {}
            stmt = null;
         }
	
      if (currentCon != null) {
         try {
            currentCon.close();
         } catch (Exception e) {
         }

         currentCon = null;
      }
   }

   	return bean;
	
   }
   
   public static UserBean signup(UserBean bean) {
		
	      //preparing some objects for connection 
	      Statement preparedStatement = null;   
		
	      String username = bean.getUsername(); 
	      String fname = bean.getFirstName();
	      String lname = bean.getLastName();
	      String password = bean.getPassword();   
		    
	      String insertQuery = "INSERT INTO user (username, password, first_name, last_name, valid) VALUES ('"+username+"', '"+password+"', '"+fname+"', '"+lname+"',1)";
	   // "System.out.println" prints in the console; Normally used to trace the process
	   System.out.println("Query: "+insertQuery);
		    
	   try {
	      //connect to DB 
	      currentCon = ConnectionManager.getConnection();
	      preparedStatement = currentCon.createStatement();
	      
	      int result = preparedStatement.executeUpdate(insertQuery);
	      System.out.println("Query: "+result);
		       
	      // if user does not exist set the isValid variable to false
	      if (result!=1) {
	         System.out.println("Sorry, error while signup");
	         bean.setValid(false);
	      } 
		        
	      //if user exists set the isValid variable to true
	      else if (result==1) {
	        	
	         System.out.println("signup succes");
	         bean.setValid(true);
	      }
	   } catch (Exception ex) {
	      System.out.println("Log In failed: An Exception has occurred! " + ex);
	   } 
		    
	   //some exception handling
	   finally {
	      if (rs != null)	{
	         try {
	            rs.close();
	         } catch (Exception e) {}
	            rs = null;
	         }
		
	      if (preparedStatement != null) {
	         try {
	            preparedStatement.close();
	         } catch (Exception e) {}
	            preparedStatement = null;
	         }
		
	      if (currentCon != null) {
	         try {
	            currentCon.close();
	         } catch (Exception e) {
	         }

	         currentCon = null;
	      }
	   }

	return bean;
		
	   }
   
   public static UserBean edit(UserBean bean) {
		
	      //preparing some objects for connection 
	      Statement preparedStatement = null;   
	      int id = bean.getId();
	      String username = bean.getUsername(); 
	      String fname = bean.getFirstName();
	      String lname = bean.getLastName();
	        
	      String updateQuery = "UPDATE user SET username='"+username+"',first_name='"+fname+"',last_name='"+lname+"' WHERE uid="+id;
	   // "System.out.println" prints in the console; Normally used to trace the process
	   System.out.println("Query: "+updateQuery);
		    
	   try {
	      //connect to DB 
	      currentCon = ConnectionManager.getConnection();
	      preparedStatement = currentCon.createStatement();
	      
	      int result = preparedStatement.executeUpdate(updateQuery);
	      System.out.println("Query: "+result);
		       
	      // if user does not exist set the isValid variable to false
	      if (result!=1) {
	         System.out.println("Sorry, error while update");
	         bean.setValid(false);
	      } 
		        
	      //if user exists set the isValid variable to true
	      else if (result==1) {
	        	
	         System.out.println("update succes");
	         bean.setValid(true);
	      }
	   } catch (Exception ex) {
	      System.out.println("update failed: An Exception has occurred! " + ex);
	   } 
		    
	   //some exception handling
	   finally {
	      if (rs != null)	{
	         try {
	            rs.close();
	         } catch (Exception e) {}
	            rs = null;
	         }
		
	      if (preparedStatement != null) {
	         try {
	            preparedStatement.close();
	         } catch (Exception e) {}
	            preparedStatement = null;
	         }
		
	      if (currentCon != null) {
	         try {
	            currentCon.close();
	         } catch (Exception e) {
	         }

	         currentCon = null;
	      }
	   }

	return bean;
		
	   }
}