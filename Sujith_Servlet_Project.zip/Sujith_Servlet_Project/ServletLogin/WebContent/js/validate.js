$(document).ready(function(){
	$('#btn_signup').click(function(e) {
	    e.preventDefault();
	    var first_name = $('#first_name').val();
	    var last_name = $('#last_name').val();
	    var username = $('#username').val();
	    var password = $('#password').val();
	    var flag = 0;
	    
	    $(".help-block").remove();
	 
	    if (first_name.length < 1) {
	    	flag = 1;
	      $('#first_name').after('<p class="help-block text-danger">Please provide your First Name</p>');
	    }
	    if (last_name.length < 1) {
	    	flag = 1;
	      $('#last_name').after('<p class="help-block text-danger">Please provide your Last Name</p>');
	    }
	    if (username.length < 1) {
	    	flag = 1;
	      $('#username').after('<p class="help-block text-danger">Please provide username</p>');
	    }
	    if (password.length < 8) {
	    	flag = 1;
	      $('#password').after(' <p class="help-block text-danger">Password should be at least 8 characters</p>');
	    }
	    
	    if(flag == 0){
	    	$('#signup_form').submit();
	    }
  });
	
	$('#btn_update').click(function(e) {
	    e.preventDefault();
	    var first_name = $('#first_name').val();
	    var last_name = $('#last_name').val();
	    var username = $('#username').val();
	    
	    var flag = 0;
	    
	    $(".help-block").remove();
	 
	    if (first_name.length < 1) {
	    	flag = 1;
	      $('#first_name').after('<p class="help-block text-danger">Please provide your First Name</p>');
	    }
	    if (last_name.length < 1) {
	    	flag = 1;
	      $('#last_name').after('<p class="help-block text-danger">Please provide your Last Name</p>');
	    }
	    if (username.length < 1) {
	    	flag = 1;
	      $('#username').after('<p class="help-block text-danger">Please provide username</p>');
	    }
	    
	    if(flag == 0){
	    	$('#edit_form').submit();
	    }
  });
	
	$('#btn_login').click(function(e) {
	    e.preventDefault();
	    var username = $('#username').val();
	    var password = $('#password').val();
	    
	    var flag = 0;
	    
	    $(".help-block").remove();
	 
	    if (username.length < 1) {
	    	flag = 1;
	      $('#username').after('<p class="help-block text-danger">Please provide username</p>');
	    }
	    if (password.length < 8) {
	    	flag = 1;
	      $('#password').after(' <p class="help-block text-danger">Password should be at least 8 characters</p>');
	    }
	    
	    if(flag == 0){
	    	$('#login_form').submit();
	    }
  });
});