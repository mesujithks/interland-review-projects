package com.interland.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.interland.model.Consumer;
 
 
public class DAO{
 
    private Session currentSession;
     
    private Transaction currentTransaction;
 
    public DAO() {
    }
 
    public Session openCurrentSession() {
        currentSession = getSessionFactory().openSession();
        return currentSession;
    }
 
    public Session openCurrentSessionwithTransaction() {
        currentSession = getSessionFactory().openSession();
        currentTransaction = currentSession.beginTransaction();
        return currentSession;
    }
     
    public void closeCurrentSession() {
        currentSession.close();
    }
     
    public void closeCurrentSessionwithTransaction() {
        currentTransaction.commit();
        currentSession.close();
    }
     
    private static SessionFactory getSessionFactory() {
    	Configuration con = new Configuration().configure().addAnnotatedClass(Consumer.class);
        ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
        SessionFactory sessionFactory = con.buildSessionFactory(reg);
        return sessionFactory;
    }
 
    public Session getCurrentSession() {
        return currentSession;
    }
 
    public void setCurrentSession(Session currentSession) {
        this.currentSession = currentSession;
    }
 
    public Transaction getCurrentTransaction() {
        return currentTransaction;
    }
 
    public void setCurrentTransaction(Transaction currentTransaction) {
        this.currentTransaction = currentTransaction;
    }
 
    public int persist(Consumer entity) {
        return (int) getCurrentSession().save(entity);
    }
 
    public void update(Consumer entity) {
        getCurrentSession().update(entity);
    }
 
    public Consumer findById(int id) {
    	Consumer book = (Consumer) getCurrentSession().find(Consumer.class, id);
        return book; 
    }
 
    public boolean delete(Consumer entity) {
        try {
			getCurrentSession().delete(entity);
			closeCurrentSessionwithTransaction();
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
    }
 
    @SuppressWarnings("unchecked")
    public List<Consumer> findAll() {
        List<Consumer> books = (List<Consumer>) getCurrentSession().createQuery("from Consumer").list();
        return books;
    }
 
    public void deleteAll() {
        List<Consumer> entityList = findAll();
        for (Consumer entity : entityList) {
            delete(entity);
        }
    }
}