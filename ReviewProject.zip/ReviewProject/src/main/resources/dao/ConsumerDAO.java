package com.interland.dao;

import java.sql.*;
import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.interland.model.Consumer;
import com.interland.util.ConnectionManager;

public class ConsumerDAO {
   static Connection currentCon = null;
   static ResultSet rs = null;

   
   public static ArrayList<Consumer> consumerSelect() {
      Statement stmt = null; 
      ArrayList<Consumer> consumers = new ArrayList<Consumer>();
      String searchQuery ="select * from consumers";
	    
	   try {
	      currentCon = ConnectionManager.getConnection();
	      stmt=currentCon.createStatement();
	      System.out.println("Query: "+searchQuery);
	      rs = stmt.executeQuery(searchQuery);
	      
	      while (rs.next()){
	    	  Consumer consumer = new Consumer();
	          consumer.setId(rs.getInt("cid"));
	          consumer.setName(rs.getString("name"));
	          consumer.setAge(rs.getInt("age"));
	          consumer.setEmail(rs.getString("email"));
	          consumer.setPhone(rs.getString("phone"));
	          consumer.setAmount(rs.getString("amount"));
	          
	          consumers.add(consumer);
	          }  
	   } catch (Exception ex) {
	      System.out.println("Selection failed: An Exception has occurred! " + ex);
	   } 
		    
	   finally {
	      if (rs != null)	{
	         try {
	            rs.close();
	         } catch (Exception e) {}
	            rs = null;
	         }
		
	      if (stmt != null) {
	         try {
	            stmt.close();
	         } catch (Exception e) {}
	            stmt = null;
	         }
		
	      if (currentCon != null) {
	         try {
	            currentCon.close();
	         } catch (Exception e) {
	        	 currentCon = null;
	         }
	      }
	   }
   	return consumers;
   }
   
   
   public static boolean consumerInsert(Consumer consumer) {
		/*
		 * Statement stmt = null; String name = consumer.getName(); int age =
		 * consumer.getAge(); String phone = consumer.getPhone(); String email =
		 * consumer.getEmail(); String amount = consumer.getAmount();
		 * 
		 * int result =0;
		 * 
		 * String insertQuery =
		 * "INSERT INTO consumers (name, age, phone, email, amount) VALUES ('"
		 * +name+"', '"+age+"', '"+phone+"', '"+email+"','"+amount+"')";
		 * 
		 * System.out.println("Query: "+insertQuery);
		 * 
		 * try { currentCon = ConnectionManager.getConnection(); stmt =
		 * currentCon.createStatement(); result = stmt.executeUpdate(insertQuery);
		 * 
		 * } catch (Exception ex) {
		 * System.out.println("Insertion failed: An Exception has occurred! " + ex); }
		 * 
		 * finally { if (rs != null) { try { rs.close(); } catch (Exception e) {} rs =
		 * null; }
		 * 
		 * if (stmt != null) { try { stmt.close(); } catch (Exception e) { stmt = null;
		 * } }
		 * 
		 * if (currentCon != null) { try { currentCon.close(); } catch (Exception e) {
		 * currentCon = null; } } }
		 */
	   
	   Configuration con = new Configuration().configure().addAnnotatedClass(Consumer.class);
       ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
       SessionFactory sf = con.buildSessionFactory(reg);
       Session session = sf.openSession();
       Transaction tx = session.beginTransaction();
       int result = (int) session.save(consumer);
       tx.commit();
	      System.out.println(result);
		   if (result==0) return true;
	   
		   else return false;
	 }

   
	public static Consumer consumerGetById(String id) {
	    Statement stmt = null; 
	    Consumer consumer = new Consumer();
	    String searchQuery ="select * from consumers where cid="+id;
		    
		 try { 
		    currentCon = ConnectionManager.getConnection();
		    stmt=currentCon.createStatement();
		    System.out.println("Query: "+searchQuery);
		    rs = stmt.executeQuery(searchQuery);
		    
		    if (rs.next()){
		        consumer.setId(rs.getInt("cid"));
		        consumer.setName(rs.getString("name"));
		        consumer.setAge(rs.getInt("age"));
		        consumer.setEmail(rs.getString("email"));
		        consumer.setPhone(rs.getString("phone"));
		        consumer.setAmount(rs.getString("amount"));
		        }  
		 } catch (Exception ex) {
		    System.out.println("Selection failed: An Exception has occurred! " + ex);
		 } 
			    
		 finally {
		    if (rs != null)	{
		       try {
		          rs.close();
		       } catch (Exception e) {}
		          rs = null;
		       }
			
		    if (stmt != null) {
		       try {
		          stmt.close();
		       } catch (Exception e) {}
		          stmt = null;
		       }
			
		    if (currentCon != null) {
		       try {
		          currentCon.close();
		       } catch (Exception e) {
		       }
		
		       currentCon = null;
		    }
		 }
	
	 	return consumer;
	}

	
	public static boolean consumerUpdate(Consumer consumer) { 
	    Statement stmt = null;   
	    int id = consumer.getId();
	    String name = consumer.getName();
	    int age = consumer.getAge();
	    String phone = consumer.getPhone();
	    String email = consumer.getEmail();
	    String amount = consumer.getAmount();
	    
	    int result =0;
	   
	    String updateQuery = "UPDATE consumers SET name='"+name+"',age='"+age+"',phone='"+phone+"',email='"+email+"',amount='"+amount+"' WHERE cid="+id;
	    System.out.println("Query: "+updateQuery);
		    
	    try {
		    currentCon = ConnectionManager.getConnection();
		    stmt = currentCon.createStatement();
		    result = stmt.executeUpdate(updateQuery);
			       
		 } catch (Exception ex) {
		    System.out.println("Update failed: An Exception has occurred! " + ex);
		 } 

		 finally {
		    if (rs != null)	{
		       try {
		          rs.close();
		       } catch (Exception e) {}
		          rs = null;
		       }
			
		    if (stmt != null) {
		       try {
		    	   stmt.close();
		       } catch (Exception e) {}
		       		stmt = null;
		       }
			
		    if (currentCon != null) {
		       try {
		          currentCon.close();
		       } catch (Exception e) {
			       currentCon = null;
		       }
		    }
		 }
	    
		 if (result==1) return true;
		 
		 else return false;
	}

	
	public static boolean consumerDelete(int id) {
		Statement stmt = null;
		int flag = 0;
		String deleteQuery = "delete from consumers where cid = "+id;
		 System.out.println("Query: "+deleteQuery);
			    
		 try {
			    currentCon = ConnectionManager.getConnection();
			    stmt=currentCon.createStatement();
			    flag = stmt.executeUpdate(deleteQuery);
			 } catch (Exception ex) {
			    System.out.println("Delete failed: An Exception has occurred! " + ex);
			 } 
				    
			 finally {
			    if (rs != null)	{
			       try {
			          rs.close();
			       } catch (Exception e) {}
			          rs = null;
			       }
				
			    if (stmt != null) {
			       try {
			          stmt.close();
			       } catch (Exception e) {}
			          stmt = null;
			       }
				
			    if (currentCon != null) {
			       try {
			          currentCon.close();
			       } catch (Exception e) {
				       currentCon = null;
			       }
			    }
			 }
		 
		 if (flag==1) return true;
		 
		 else return false;
	}
	 
}