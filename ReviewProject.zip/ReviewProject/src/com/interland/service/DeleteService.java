package com.interland.service;

import com.interland.dao.DAO;
import com.interland.model.Consumer;

public class DeleteService {
	
	private static DAO dao;
	 
    public DeleteService() {
    	dao = new DAO();
    }

	
	public boolean deleteConsumer(int id) {
		dao.openCurrentSessionwithTransaction();
        Consumer book = new Consumer();
        		book.setId(id);
		boolean result = dao.delete(book);
		dao.closeCurrentSessionwithTransaction();
		return result;
	       
		
		
	}

}
