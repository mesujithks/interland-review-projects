package com.interland.service;

import com.interland.model.Consumer;
import com.interland.dao.DAO;

public class AddService {
	
	private static DAO dao;
	 
    public AddService() {
    	dao = new DAO();
    }

	public boolean adService(Consumer consumer)
	{
		dao.openCurrentSessionwithTransaction();
        boolean rs = dao.persist(consumer);
        dao.closeCurrentSessionwithTransaction();
        
        return rs;
	}
}
