package com.interland.service;

import com.interland.dao.DAO;
import com.interland.model.Consumer;

public class EditService {

	private static DAO dao;

	public EditService() {
		dao = new DAO();
	}

	public Consumer getConsumer(String id) {
		dao.openCurrentSessionwithTransaction();
        Consumer consumer= dao.findById(Integer.parseInt(id));
        dao.closeCurrentSessionwithTransaction();
		return consumer;
	}

	public boolean editConsumer(Consumer consumer) {

		dao.openCurrentSessionwithTransaction();
        boolean rs = dao.update(consumer);
        dao.closeCurrentSessionwithTransaction();
        return rs;
	}

}
