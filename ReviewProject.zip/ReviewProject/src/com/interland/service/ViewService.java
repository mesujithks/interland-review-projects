package com.interland.service;

import java.util.ArrayList;

import com.interland.dao.DAO;
import com.interland.model.Consumer;

public class ViewService {

	private static DAO dao;

	public ViewService() {
		dao = new DAO();
	}

	public ArrayList<Consumer> getConsumers() {
		{
			dao.openCurrentSessionwithTransaction();
			ArrayList<Consumer> consumers = (ArrayList<Consumer>) dao.findAll();
			dao.closeCurrentSessionwithTransaction();
			return consumers;

		}
	}
}

// public ArrayList<Consumer> getConsumers(){

// return ConsumerDAO.consumerSelect();

// }
