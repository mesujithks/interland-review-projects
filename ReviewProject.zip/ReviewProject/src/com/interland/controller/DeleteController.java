package com.interland.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.interland.service.DeleteService;


@WebServlet("/DeleteController")
public class DeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		DeleteService service = new DeleteService();
		boolean ajax = "XMLHttpRequest".equals(request.getHeader("X-Requested-With"));

		try {
			response.setContentType("text/html");  
			PrintWriter pw=response.getWriter();
			
			if (ajax) {
				if(service.deleteConsumer(Integer.parseInt(request.getParameter("id").trim()))) {
					pw.println("1");  
				} else {
					pw.println("0");  
				}
				pw.close();
			} else {
			    response.sendRedirect("delete.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.sendRedirect("delete.jsp");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
