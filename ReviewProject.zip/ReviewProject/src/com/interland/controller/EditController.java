package com.interland.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.interland.model.Consumer;
import com.interland.service.EditService;


@WebServlet("/EditServlet")
public class EditController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EditService service = new EditService();
		PrintWriter out=response.getWriter();
		Gson gson = new Gson();
		boolean ajax = "XMLHttpRequest".equals(request.getHeader("X-Requested-With"));
		try {
			Consumer consumer = service.getConsumer(request.getParameter("id").trim());
			if (ajax) {
				response.setContentType("application/json"); 
				response.setCharacterEncoding("UTF-8");
				out.print(gson.toJson(consumer));
				out.flush();
				out.close(); 
			} else {
			    response.sendRedirect("edit.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.sendRedirect("edit.jsp");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Consumer consumer = new Consumer();
		PrintWriter out=response.getWriter();
		HashMap<String, String> message = new HashMap<String, String>();
		EditService service=new EditService();
		boolean ajax = "XMLHttpRequest".equals(request.getHeader("X-Requested-With"));
		
		try {
			consumer.setId(Integer.parseInt(request.getParameter("id").trim()));
			consumer.setName(request.getParameter("name").trim());
			consumer.setAge(Integer.parseInt(request.getParameter("age").trim()));
			consumer.setPhone(request.getParameter("phone").trim());
			consumer.setEmail(request.getParameter("email").trim());
			consumer.setAmount(request.getParameter("amount").trim());
			
			response.setContentType("application/json"); 
			response.setCharacterEncoding("UTF-8");
			
			message.put("page", "edt");
			
			if (ajax) {
				if(service.editConsumer(consumer)) {
					message.put("type", "alert-success");
					message.put("data", "Consumer Updated.");
					out.print(new JSONObject(message));
					out.flush();
				} else {
					message.put("type", "alert-danger");
					message.put("data", "Error while updating Consumer! Please Try Again.");
					out.print(new JSONObject(message));
					out.flush();
				}
				out.close();
			} else {
			    response.sendRedirect("edit.jsp");
			}
		} catch (NumberFormatException e) {
			e.printStackTrace();
			response.sendRedirect("edit.jsp");
		}
	}

}
