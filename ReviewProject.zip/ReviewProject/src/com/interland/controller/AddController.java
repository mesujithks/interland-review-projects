package com.interland.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.interland.model.Consumer;
import com.interland.service.AddService;


@WebServlet("/AddController")
public class AddController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Consumer consumer = new Consumer();
		PrintWriter out=response.getWriter();
		HashMap<String, String> message = new HashMap<String, String>();
		AddService add=new AddService();
		boolean ajax = "XMLHttpRequest".equals(request.getHeader("X-Requested-With"));

		try {
			consumer.setName(request.getParameter("name").trim());
			consumer.setAge(Integer.parseInt(request.getParameter("age").trim()));
			consumer.setPhone(request.getParameter("phone").trim());
			consumer.setEmail(request.getParameter("email").trim());
			consumer.setAmount(request.getParameter("amount").trim());
			
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			
			message.put("page", "add");
			
			if (ajax) {
				if(add.adService(consumer)) { 
					message.put("type", "alert-success");
					message.put("data", "New Consumer Added.");
					out.print(new JSONObject(message));
					out.flush(); 
				} else {
					message.put("type", "alert-danger");
					message.put("data", "Error while adding Consumer! Please Try Again.");
					out.print(new JSONObject(message));
					out.flush(); 
				}
				out.close();
			} else {
			    response.sendRedirect("add.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.sendRedirect("add.jsp");
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
}
