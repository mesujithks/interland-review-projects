package com.interland.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;

import com.google.gson.Gson;
import com.interland.model.Consumer;
import com.interland.service.ViewService;


@WebServlet("/View")
public class ViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ViewService view = new ViewService();
		PrintWriter out=response.getWriter();
		JSONArray jsonArray = new JSONArray();
		Gson gson = new Gson();
		boolean ajax = "XMLHttpRequest".equals(request.getHeader("X-Requested-With"));

		try {
			if (ajax) {
				response.setContentType("application/json"); 
				response.setCharacterEncoding("UTF-8");
		
				for(Consumer consumer: view.getConsumers()) {
					jsonArray.put(gson.toJson(consumer));
				}
				out.print(jsonArray);
				out.flush();
				out.close();
			} else {
			    response.sendRedirect("index.jsp");
			}
		} catch (Exception e) {
			e.printStackTrace();
			response.sendRedirect("index.jsp");
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
