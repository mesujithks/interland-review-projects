package com.interland.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import com.interland.model.Consumer;

public class DAO {
	private Session currentSession;
    
    private Transaction currentTransaction;
 
    public DAO() {
    }
 
    public Session openCurrentSession() {
        currentSession = getSessionFactory().openSession();
        return currentSession;
    }
 
    public Session openCurrentSessionwithTransaction() {
        currentSession = getSessionFactory().openSession();
        currentTransaction = currentSession.beginTransaction();
        return currentSession;
    }
     
    public void closeCurrentSession() {
        currentSession.close();
    }
     
    public void closeCurrentSessionwithTransaction() {
        currentTransaction.commit();
        currentSession.close();
    }
     
    private static SessionFactory getSessionFactory() {
    	Configuration con = new Configuration().configure().addAnnotatedClass(Consumer.class);
        ServiceRegistry reg = new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
        SessionFactory sessionFactory = con.buildSessionFactory(reg);
        return sessionFactory;
    }
 
    public Session getCurrentSession() {
        return currentSession;
    }
 
    public void setCurrentSession(Session currentSession) {
        this.currentSession = currentSession;
    }
 
    public Transaction getCurrentTransaction() {
        return currentTransaction;
    }
 
    public void setCurrentTransaction(Transaction currentTransaction) {
        this.currentTransaction = currentTransaction;
    }
 
    public boolean persist(Consumer entity) {
        try {
			getCurrentSession().save(entity);
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
    }
 
    public boolean update(Consumer entity) {
        try {
			getCurrentSession().update(entity);
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
    }
 
    public Consumer findById(int id) {
    	Consumer consumer = (Consumer) getCurrentSession().get(Consumer.class, id);
        return consumer; 
    }
 
    public boolean delete(Consumer entity) {
        try {
			getCurrentSession().delete(entity);
			return true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
    }
 
    @SuppressWarnings("unchecked")
    public List<Consumer> findAll() {
    	//@SuppressWarnings("deprecation")
		//Criteria cr = getCurrentSession().createCriteria(Consumer.class);
    	//List<Consumer> consumers = (List<Consumer>)cr.list();
       List<Consumer> consumers = (List<Consumer>) getCurrentSession().createQuery("from Consumer").list();
        return consumers;
    }
 
    public void deleteAll() {
        List<Consumer> entityList = findAll();
        for (Consumer entity : entityList) {
            delete(entity);
        }
    }
}
