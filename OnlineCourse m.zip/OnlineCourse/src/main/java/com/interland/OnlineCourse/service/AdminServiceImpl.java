package com.interland.OnlineCourse.service;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.interland.OnlineCourse.dao.UserDAO;
import com.interland.OnlineCourse.dto.UserEdit;
import com.interland.OnlineCourse.model.Course;
import com.interland.OnlineCourse.model.Notice;
import com.interland.OnlineCourse.model.User;

@Service
public class AdminServiceImpl implements AdminService {
	@Autowired
	UserDAO dao;

	@SuppressWarnings("unchecked")
	public JSONObject getStudentDetails(String searchParam, String sSearch, int displaystart, int idisplaylength) {
		org.json.simple.JSONObject res = new org.json.simple.JSONObject();
		org.json.simple.JSONArray employeeDetailsObjArr = new org.json.simple.JSONArray();
		try {

			List<User> lstAllEmployees = dao.searchStudentDetails(searchParam, sSearch, displaystart, idisplaylength);

			Long rowCount = dao.getRecordCountForStudentDetails(searchParam, sSearch);

			for (User userDetails : lstAllEmployees) {
				org.json.simple.JSONObject objAllEmployees = new org.json.simple.JSONObject();

				objAllEmployees.put("name", userDetails.getName());
				objAllEmployees.put("email", userDetails.getEmail());
				objAllEmployees.put("mobile", userDetails.getMobile());
				objAllEmployees.put("gender", userDetails.getGender());
				objAllEmployees.put("dob", userDetails.getDob());
				objAllEmployees.put("id", userDetails.getId());

				employeeDetailsObjArr.add(objAllEmployees);
			}
			res.put("aaData", employeeDetailsObjArr);
			res.put("iTotalDisplayRecords", rowCount);
			res.put("iTotalRecords", rowCount);
		} catch (Exception e) {

		}
		// System.out.println("service"+res);
		return res;
	}

	public String deleteStudentService(int id) {
		String message = "0";
		try {
			if (dao.delete(id))
				message = "1";

		} catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}

	public User getStudent(int id) {
		User user = null;
		try {
			user = dao.getStudent(id);
		} catch (Exception e) {
			System.out.println(e);
		}
		return user;
	}

	public String editStudentFormService(UserEdit useredit) {

		HashMap<String, String> message = new HashMap<String, String>();

		try {
			User user = dao.getStudent(useredit.getId());
			user.setName(useredit.getName());
			user.setEmail(useredit.getEmail());
			user.setType(useredit.getType());
			user.setMobile(useredit.getMobile());
			user.setGender(useredit.getGender());
			user.setDob(new SimpleDateFormat("yyyy-MM-dd").parse(useredit.getDob()));

			if (dao.addOrUpdate(user)) {
				message.put("type", "alert-success");
				message.put("data", "User Updated.");
			} else {
				message.put("type", "alert-danger");
				message.put("data", "Error while updating User! Please Try Again.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new org.json.JSONObject(message).toString();
	}

	@SuppressWarnings("unchecked")
	public JSONObject getFacultyDetails(String searchParam, String sSearch, int displaystart, int idisplaylength) {
		org.json.simple.JSONObject res = new org.json.simple.JSONObject();
		org.json.simple.JSONArray employeeDetailsObjArr = new org.json.simple.JSONArray();
		try {

			List<User> lstAllEmployees = dao.searchFacultyDetails(searchParam, sSearch, displaystart, idisplaylength);

			Long rowCount = dao.getRecordCountForFacultyDetails(searchParam, sSearch);

			for (User userDetails : lstAllEmployees) {
				org.json.simple.JSONObject objAllEmployees = new org.json.simple.JSONObject();

				objAllEmployees.put("name", userDetails.getName());
				objAllEmployees.put("email", userDetails.getEmail());
				objAllEmployees.put("mobile", userDetails.getMobile());
				objAllEmployees.put("gender", userDetails.getGender());
				objAllEmployees.put("dob", userDetails.getDob());
				objAllEmployees.put("id", userDetails.getId());

				employeeDetailsObjArr.add(objAllEmployees);
			}
			res.put("aaData", employeeDetailsObjArr);
			res.put("iTotalDisplayRecords", rowCount);
			res.put("iTotalRecords", rowCount);
		} catch (Exception e) {

		}
		// System.out.println("service"+res);
		return res;
	}

	@SuppressWarnings("unchecked")
	public JSONObject getCourseDetails(String searchParam, String sSearch, int displaystart, int idisplaylength) {
		org.json.simple.JSONObject res = new org.json.simple.JSONObject();
		org.json.simple.JSONArray employeeDetailsObjArr = new org.json.simple.JSONArray();
		try {

			List<Course> lstAllEmployees = dao.searchCourseDetails(searchParam, sSearch, displaystart, idisplaylength);

			Long rowCount = dao.getRecordCountForCourseDetails(searchParam, sSearch);

			for (Course userDetails : lstAllEmployees) {
				org.json.simple.JSONObject objAllEmployees = new org.json.simple.JSONObject();

				objAllEmployees.put("courseName", userDetails.getCourseName());
				objAllEmployees.put("shortD", userDetails.getShortD());
				// objAllEmployees.put("longD", userDetails.getLongD());
				objAllEmployees.put("courseImage", userDetails.getCourseImage());
				objAllEmployees.put("courseId", userDetails.getCourseId());

				employeeDetailsObjArr.add(objAllEmployees);
			}
			res.put("aaData", employeeDetailsObjArr);
			res.put("iTotalDisplayRecords", rowCount);
			res.put("iTotalRecords", rowCount);
		} catch (Exception e) {

		}
		// System.out.println("service"+res);
		return res;
	}

	public String addCourseService(Course course) {
		HashMap<String, String> message = new HashMap<String, String>();

		try {

			if (dao.addOrUpdateCourse(course)) {
				message.put("type", "alert-success");
				message.put("data", "New Course Added.");
			} else {
				message.put("type", "alert-danger");
				message.put("data", "Error while adding Course! Please Try Again.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new org.json.JSONObject(message).toString();
	}

	public String editCourseService(Course course) {
		HashMap<String, String> message = new HashMap<String, String>();

		try {

			if (dao.addOrUpdateCourse(course)) {
				message.put("type", "alert-success");
				message.put("data", "Course Updated.");
			} else {
				message.put("type", "alert-danger");
				message.put("data", "Error while editing Course! Please Try Again.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new org.json.JSONObject(message).toString();
	}

	public Course getCourse(int id) {
		Course course= null;
		try {
			course = dao.getCourse(id);
		} catch (Exception e) {
			System.out.println(e);
		}
		return course;
	}

	public String deleteCourseService(int id) {
		String message = "0";
		try {
			if (dao.deleteCourse(id))
				message = "1";

		} catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}

	@SuppressWarnings("unchecked")
	public JSONObject getNoticeDetails(String searchParam, String sSearch, int displaystart, int idisplaylength) {
		org.json.simple.JSONObject res = new org.json.simple.JSONObject();
		org.json.simple.JSONArray employeeDetailsObjArr = new org.json.simple.JSONArray();
		try {

			List<Notice> lstAllEmployees = dao.searchNoticeDetails(searchParam, sSearch, displaystart, idisplaylength);

			Long rowCount = dao.getRecordCountForNoticeDetails(searchParam, sSearch);

			for (Notice userDetails : lstAllEmployees) {
				org.json.simple.JSONObject objAllEmployees = new org.json.simple.JSONObject();

				objAllEmployees.put("noticeId", userDetails.getNoticeId());
				objAllEmployees.put("title", userDetails.getTitle());
				objAllEmployees.put("content", userDetails.getContent());
				

				employeeDetailsObjArr.add(objAllEmployees);
			}
			res.put("aaData", employeeDetailsObjArr);
			res.put("iTotalDisplayRecords", rowCount);
			res.put("iTotalRecords", rowCount);
		} catch (Exception e) {

		}
		// System.out.println("service"+res);
		return res;
	}

	public String addNoticeService(Notice notice) {
		HashMap<String, String> message = new HashMap<String, String>();

		try {

			if (dao.addOrUpdateNotice(notice)) {
				message.put("type", "alert-success");
				message.put("data", "Notice added.");
			} else {
				message.put("type", "alert-danger");
				message.put("data", "Error while adding Notice! Please Try Again.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new org.json.JSONObject(message).toString();
	}

	public Notice getNotice(int id) {
		Notice notice = null;
		try {
			notice = dao.getNotice(id);
		} catch (Exception e) {
			System.out.println(e);
		}
		return notice;
	}

	public String editNoticeService(Notice notice) {
		HashMap<String, String> message = new HashMap<String, String>();

		try {

			if (dao.addOrUpdateNotice(notice)) {
				message.put("type", "alert-success");
				message.put("data", "Notice Updated.");
			} else {
				message.put("type", "alert-danger");
				message.put("data", "Error while updating Notice! Please Try Again.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new org.json.JSONObject(message).toString();
	}

	public String deleteNoticeService(int id) {
		String message = "0";
		try {
			if (dao.deleteNotice(id))
				message = "1";

		} catch (Exception e) {
			e.printStackTrace();
		}
		return message;
	}

}
