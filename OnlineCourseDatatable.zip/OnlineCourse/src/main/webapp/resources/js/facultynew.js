$(document).ready(function() {
	
	/*$.ajax({
		"url" : "getTableHead",
		"dataType" : "json",
		"type" : "GET",
		"success" : function(res) {
			console.log(res);
			var i;
			var h = res["head"];
			for(i=0;i<h.length;i++){
				$("thead tr").append('<th>'+h[i]+'</th>');
				$("#chkBox").append('<li><label class="radio-btn"> <input type="checkbox" name="hide_coloumn" value="'+i+'" id="chkItem_'+i+'" >'+h[i]+'</label></li>');
			}
		}
	});*/

	var run = false;
	var consumers = $('#Faculty').DataTable({
		colReorder : true,
		stateSave : true,
		"stateSaveCallback" : function(settings, data) {
			if(run){
				// Send an Ajax request to the server with the state object
				$.ajax({
					"url" : "setTablePref",
					"data" : {
						json : JSON.stringify(data)
					},
					"dataType" : "json",
					"type" : "POST",
					"success" : function(r) {
						console.log(r);
					}
				});
			run = false;
			}
			
		},
		"stateLoadCallback" : function(settings, callback) {
			$.ajax({
				url : 'getTablePref',
				dataType : 'json',
				success : function(json) {
					if (JSON.stringify(json).length > 0)
						callback(json);
					else
						callback(null);
					//Set the hidden column checkbox true.
					consumers.columns().every(function() {
						if (!this.visible())
							$('#chkItem_' + this[0][0]).prop('checked', true);
					});
				},
				error : function(json) {
					console.log(json);
					callback(null);
				}
			});
		},
		"bProcessing" : true,
		"bDeferRender" : true,
		bAutoWidth : false,
		bServerSide : true,
		sAjaxSource : "FacultyTableList",
		"iDisplayLength" : 5,
		"aLengthMenu" : [ [ 5, 10, 25, 50, 100 ], [ 5, 10, 25, 50, 100 ] ],
		"sPaginationType" : "full_numbers",
		"bPaginate" : true,
		"fnServerParams" : function(aoData) {
			var employeeCodeSearch = $("#customSearchBox").val();

			var dataString = JSON.stringify({
				employeeCode : employeeCodeSearch
			});
			aoData.push({
				name : "searchData",
				value : dataString
			});
		},
		"fnServerData" : function(sSource, aoData, fnCallback, oSettings) {
			oSettings.jqXHR = $.ajax({
				"dataType" : 'json',
				"type" : "POST",
				"url" : sSource,
				"data" : aoData,
				"success" : fnCallback,
				"error" : function(e) {
					console.log(e);
				}
			});
		},
		"aaSorting" : [ [ 1, "asc" ] ],
		"sDom" : 'rt<lp>',
		"aoColumns" : [ {
			"mDataProp" : "name",
			"bSortable" : false
		}, {
			"mDataProp" : "email",
			"bSortable" : false
		}, {
			"mDataProp" : "mobile",
			"bSortable" : false
		}, {
			"mDataProp" : "gender",
			"bSortable" : false
		}, {
			"mDataProp" : "dob",
			"bSortable" : false
		}

		]
	});

	$('#hideColoumn').on('click', function(e) {
		//e.preventDefault();
		var coloumns = [];
		var od = consumers.colReorder.order();
		var i;
		var pos = -1;

		consumers.columns(od).visible(true);

		$.each($("input[name='hide_coloumn']:checked"), function() {
			coloumns.push($(this).val());
			var curEl = $(this).val();
			od = consumers.colReorder.order();
			for (i = 0; i < od.length; i++) {

				if (od[i] == curEl)
					pos = i;
			}

			// Get the column API object
			var column = consumers.column(pos);

			// Toggle the visibility
			column.visible(false);
		});
		console.log("table order: " + od);
		console.log("hidden coloumns: " + coloumns);
		run = true;
		consumers.state.save(run);
		$(".row").after('<div class="page-alerts"><br /><div class="alert alert-success" role="alert">Table preferences saved.</div></div>');
    	$(".page-alerts").fadeOut(3000,function(){
			 $(this).remove();
    	});
	});
	
	$('#saveBtn').on('click', function() {
		run = true;
		consumers.state.save(run);
		$(".row").after('<div class="page-alerts"><br /><div class="alert alert-success" role="alert">Table preferences saved.</div></div>');
    	$(".page-alerts").fadeOut(2000,function(){
			 $(this).remove();
    	});
	});

	$("#customSearchBoxBtn").click(function() {
		Cookies.set('search', $("#customSearchBox").val());
		consumers.draw();
	});
	
	var srch = Cookies.get("search").trim();
	if(srch.length>0){
		$("#customSearchBox").val(srch);
		$("#customSearchBoxBtn").click();
	}

});