package com.interland.OnlineCourse.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.interland.OnlineCourse.dto.UserLogin;
import com.interland.OnlineCourse.dto.UserRegister;
import com.interland.OnlineCourse.model.User;
import com.interland.OnlineCourse.service.AdminService;
import com.interland.OnlineCourse.service.FacultyService;
import com.interland.OnlineCourse.service.MianService;

@Controller
public class MainController {

	@Autowired
	MianService service;
	
	@Autowired
	AdminService service1;
	
	private static final Logger LOGGER = LogManager.getLogger(MainController.class.getName());

	@RequestMapping("/index")
	public String indexPage() {
		LOGGER.info("Inside index");
		return "index";
	}
	

	@RequestMapping(value = "/RegisterForm", method = RequestMethod.POST)
	public ModelAndView indexAction(@ModelAttribute UserRegister userRegister) {
		LOGGER.info("Inside RegisterForm");

		ModelAndView mv = new ModelAndView();
		mv.setViewName("index");
		mv.addObject("result", service.registerService(userRegister));
		return mv;
	}

	@RequestMapping(value = "/LoginForm", method = RequestMethod.POST)
	public String indexAction(Model model,@ModelAttribute UserLogin userLogin, HttpServletRequest request) {
		LOGGER.info("Inside LoginForm");
		String page ="index";
		User user =null;
		HashMap<String, String> response = new HashMap<String, String>();
		HttpSession session= request.getSession();
		
		try {
			user = service.loginService(userLogin);
			if (user != null) {
				session.setAttribute("id", user.getId());
				session.setAttribute("name", user.getName());
				session.setAttribute("type", user.getType());
				
				if (user.getType().equals("admin"))
					page ="admin/index";
				else if (user.getType().equals("faculty"))
					page = "faculty/index";
				else if (user.getType().equals("student"))
					page = "student/index";
			}else {
				response.put("flag", "false");
				response.put("message", "Error");
				model.addAttribute("result", response);
			}
		} catch (Exception e) {
			LOGGER.error("Inside LoginForm: " + e.getMessage());
		}
		return "redirect:/"+page;
	}
	
	@RequestMapping("/Logout")
	public String logout(HttpServletRequest request) {
		LOGGER.info("Inside Logout");
		HttpSession session = request.getSession(false);
		if(session != null){
			session.invalidate();
		}
		return "index";
	}
	
	@RequestMapping("faculties")
	public String facultyPage() {
		LOGGER.info("Inside Faculty");
		return "faculty";
	}

	@RequestMapping(value = "FacultyTableList", method = RequestMethod.POST)
	public @ResponseBody org.json.simple.JSONObject facultyDetails(HttpServletRequest request) {
		LOGGER.info("Inside FacultyTableList");
		org.json.simple.JSONObject res = null;
		int idisplaylength = Integer.parseInt(request.getParameter("iDisplayLength"));
		int displaystart = Integer.parseInt(request.getParameter("iDisplayStart"));
		String sSearch = request.getParameter("sSearch");
		String searchParam = request.getParameter("searchData");

		try {
			res = service1.getFacultyDetails(searchParam, sSearch, displaystart, idisplaylength);	
		} catch (Exception e) {
			LOGGER.error("Inside FacultyTableList: " + e.getMessage());
		}
		LOGGER.debug("Inside FacultyTableList: " + res.toString());
		return res;
	}

}
