package com.interland.OnlineCourse.dao;

import java.util.List;

import com.interland.OnlineCourse.model.User;

public interface BatchDao {
	
	public List<User> getNewUsers();
	
	public boolean setUserSendMail(User user);

}
